#include "../include/heap.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

struct rep_heap {
	info_t *dato;
	nat *valor_nat;
	nat tamanio;
	nat max_valor;
	nat cantidad_actual;
};

heap_t crear_heap(nat tamanio, nat max_valor){
	heap_t nuevo = new rep_heap;
	nuevo->dato = new info_t[tamanio + 1];
	nuevo->valor_nat = new nat[max_valor + 1];
	nuevo->tamanio = tamanio;
	nuevo->max_valor = max_valor;
	nuevo->cantidad_actual = 0;
	for (nat i = 0; i < nuevo->tamanio + 1; i++){
		nuevo->dato[i] = NULL;
	}
	for (nat i = 0; i <= nuevo->max_valor; i++){
		nuevo->valor_nat[i] = 0;
	}
	return nuevo;
}

nat hijo_izquierdo(nat i){
	return (2*i);
}

nat hijo_derecho(nat i){
	return ((2*i) + 1);
}
nat padre(nat i){
	return (i/2);
}

void intercambiar_nats(nat x, nat y, heap_t h){
	info_t aux;
	nat aux_indices_valor_nat;
	nat val1 = numero_info(h->dato[x]);
	nat val2 = numero_info(h->dato[y]);
	aux = h->dato[x];
	h->dato[x] = h->dato[y];
	h->dato[y] = aux;
	aux_indices_valor_nat = h->valor_nat[val1];
	h->valor_nat[val1] = h->valor_nat[val2];
	h->valor_nat[val2] = aux_indices_valor_nat;
}

bool comparar(nat nuevo, nat padre, heap_t h){
	return numero_info(h->dato[nuevo]) < numero_info(h->dato[padre]);
}

void insertar_en_heap(info_t i, heap_t &h) {
	nat v = numero_info(i);
	nat indice_nuevo =  h->cantidad_actual + 1;
	assert(!es_lleno_heap(h) && !hay_valor(v,h) && v <= max_valor(h));
	h->valor_nat[v] = indice_nuevo;
	if (h->cantidad_actual > 0){
		nat indice_padre = padre(indice_nuevo);
		h->dato[indice_nuevo] = i;
		while (indice_padre > 0 && comparar(indice_nuevo, indice_padre, h)){
			intercambiar_nats(indice_padre, indice_nuevo, h);
			indice_nuevo = indice_padre;
			indice_padre = padre(indice_nuevo);
		}
	} else
		h->dato[indice_nuevo] = i;
	h->cantidad_actual++;
}

void reducir(nat v, heap_t &h) {
	assert(hay_valor(v, h) && !hay_valor(v/2, h));
	nat indice = h->valor_nat[v];
 	intercambiar_nats(indice, h->cantidad_actual, h);
	indice = h->cantidad_actual;
 	char *copia = new char[strlen(frase_info(h->dato[indice])) + 1]; 
	strcpy(copia, frase_info(h->dato[indice]));
	info_t modificado = crear_info(v/2, copia);
	liberar_info(h->dato[indice]);
	h->dato[indice] = modificado;//
	nat indice_padre = padre(indice);
	h->valor_nat[v] = 0;
	h->valor_nat[v/2] = indice;
	while (indice_padre > 0 && comparar(indice, indice_padre, h)){
		intercambiar_nats(indice_padre, indice, h);
		indice = indice_padre;
		indice_padre = padre(indice);
	}
}

void eliminar_menor(heap_t &h) {
	assert(!es_vacia_heap(h));
	nat aux = 1;
	nat indice_ultimo = h->cantidad_actual;
	intercambiar_nats(aux, indice_ultimo, h);
	h->valor_nat[numero_info(h->dato[indice_ultimo])] = 0;
	liberar_info(h->dato[indice_ultimo]);
	h->dato[indice_ultimo] = NULL;
	nat saltar = -1;
	while (saltar != 0 && aux < indice_ultimo) {
		if (hijo_izquierdo(aux) < h->cantidad_actual) 
			if (hijo_derecho(aux) < h->cantidad_actual)
				if (comparar(hijo_derecho(aux), hijo_izquierdo(aux), h))
					saltar = hijo_derecho(aux);
				else
					saltar = hijo_izquierdo(aux);
			else
				if (comparar(hijo_izquierdo(aux), aux, h))
					saltar = hijo_izquierdo(aux);
				else
					saltar = 0;
		else
			if (hijo_derecho(aux) <= h->cantidad_actual)
				if (comparar(hijo_derecho(aux), aux, h))
					saltar = hijo_derecho(aux);
				else
					saltar = 0;
			else 
				saltar = 0;
		if (saltar != 0)
			intercambiar_nats(saltar, aux, h);
		aux = saltar;	
	}
	h->cantidad_actual--;
}

void liberar_heap(heap_t &h) {
	for (nat i = 1; i < h->cantidad_actual + 1; i++) {
		liberar_info(h->dato[i]);		
	}
	delete[] h->dato;
	delete[] h->valor_nat;
	delete h;
}

bool es_vacio_heap(heap_t h){
	return h->cantidad_actual == 0;
}

bool es_lleno_heap(heap_t h){
	return h->tamanio == h->cantidad_actual;
}

bool hay_valor(nat v, heap_t h){
	return h->valor_nat[v] != 0;
}

info_t menor(heap_t h){
	assert(!es_vacio_h(h));	
	return h->dato[1];
}

nat max_valor(heap_t h){
	return h->max_valor;
}