#include <stdio.h>
#include <assert.h>
#include "../include/binario.h"
#include "../include/colaAvls.h"

// Representación de TColaAvls'.
// Se debe definir en colaAvls.cpp
// struct repColaAvls;
// Declaración del tipo 'TColaAvls'
//typedef struct repColaAvls *TColaAvls;

struct nodo {
	TAvl dato;
	nodo *siguiente;
};

struct repColaAvls{
	nodo *primero;
	nodo *ultimo;
};

/*
  Devuelve una 'TColaAvls' vacía (sin elementos).
  El tiempo de ejecución en el peor caso es O(1).
 */
TColaAvls crearColaAvls() {
	TColaAvls res = new repColaAvls;
	res->primero = res->ultimo = NULL;
	return res;
}

/*
  Encola 'avl' en 'c'.
  Devuelve 'c'.
  El tiempo de ejecución en el peor caso es O(1).
 */
TColaAvls encolar(TAvl avl, TColaAvls c) {
	nodo *nuevo = new nodo;
	nuevo->dato = avl;
	nuevo->siguiente = NULL;
	if (estaVaciaColaAvls(c)) 
		c->primero = nuevo;
	else 
		c->ultimo->siguiente = nuevo;
	c->ultimo = nuevo;
	return c;
}

/*
  Remueve de 'c' el elemento que está en el frente.
  Si estaVaciaColaAvls(c) no hace nada.
  Devuelve 'c'.
  NO libera la memoria del elemento removido.
  El tiempo de ejecución en el peor caso es O(1).
 */
TColaAvls desencolar(TColaAvls c)  {
	assert(c->primero != NULL);
	nodo *temp = c->primero;
	c->primero = c->primero->siguiente;
	if (c->primero == NULL) 
		c->ultimo = NULL;
	delete temp;
	return c;
}
/*
  Libera la memoria asignada a 'c', pero NO la de sus elementos.
  El tiempo de ejecución en el peor caso es O(n), siendo 'n' la cantidad
  de elementos de 'c'.
 */
void liberarColaAvls(TColaAvls c) {
	nodo *temp;
	while (c->primero != NULL){
		temp = c->primero;
		c->primero = c->primero->siguiente;
		delete temp;
	}
	delete c;
}
/*
  Devuelve 'true' si y solo si 'c' es vacía (no tiene elementos).
  El tiempo de ejecución en el peor caso es O(1).
 */
bool estaVaciaColaAvls(TColaAvls c) {
	return c->primero == NULL;
}

/*
  Devuelve el elemento que está en el frente de 'c'.
  Precondición: !estaVaciaColaAvls(c);
  El tiempo de ejecución en el peor caso es O(1).
 */
TAvl frente(TColaAvls c){ 
	assert(!estaVaciaColaAvls(c));
	return c->primero->dato;
}