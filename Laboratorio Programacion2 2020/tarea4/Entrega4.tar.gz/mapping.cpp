/*
	Módulo de definición de 'TMapping'.

	'TMapping' es un mapping de asociaciones de elementos de
	tipo nat con elementos de tipo double.

	Laboratorio de Programación 2.
	InCo-FIng-UDELAR
*/

#include "../include/utils.h"
#include "../include/mapping.h"
#include "../include/info.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

// Representación de 'TMapping'.
// Se debe definir en mapping.cpp.
// struct repMap;
// Declaración del tipo 'TMapping'.
//typedef struct repMap *TMapping;

struct repInfo {
  nat n;
  double r;
};
typedef struct repInfo *TInfo;
/*
	Representacion de el mappig, que vendria siendo 
	el "casillero" donde van calzando los "paquetes"
	Estas casillas se llaman m->data[i] y cada m->data[i] tiene .valor y .clave
	m->data[i].valor, m->data[i].clave
*/
struct repMap {
	TInfo *dato;
	nat *valorNat;
	nat cantidadActual;
	nat tamanio;
};

/*
  Crea un 'TMapping' vacío (sin elementos) de asociaciones nat -> double.
  Podrá haber hasta M asociaciones.
  El tiempo de ejecución en el peor caso es O(M).
 */
TMapping crearMap(nat M) {
	TMapping map = new repMap;
	map->dato = new TInfo[(M + 1) * 10];
	map->valorNat = new nat[(M + 1) * 10];
	map->tamanio = M;
	map->cantidadActual = 0;
	for (nat i = 0; i < (M + 1) * 10; i++) {
		map->dato[i] = 0;
		map->valorNat[i] = 0;
	}
	return map;
}

/*
  Inserta en 'map' la asociación entre 'clave' y 'valor'.
  Precondición: !estaLlenoMap(map) y !existeAsociacionEnMap(clave, map).
  Devuelve 'map'.
  El tiempo de ejecución en el peor caso es O(1).
 */
TMapping asociarEnMap(nat clave, double valor, TMapping map) {
	map->cantidadActual++;
	map->dato[clave] = crearInfo(clave, valor);
	map->valorNat[clave] = map->cantidadActual;		
	return map;
}


/*
  Elimina de 'map' la asociación correspondiente a 'clave' y libera la
  menoria  asignada a mantener esa asociación.
  Precondición: existeAsociacionenMap(clave, h).
  Devuelve 'map'.
  El 'TMapping' resultado comparte memoria con el parámetro'.
  El tiempo de ejecución es O(1) en promedio.
 */

TMapping desasociarEnMap(nat clave, TMapping map) {
	assert(existeAsociacionEnMap(clave, map));
	map->cantidadActual--;
	map->valorNat[clave] = 0;
	liberarInfo(map->dato[clave]);

	return map;	
}
	
/*
	Devuelve 'true' si y solo si en 'map' hay una asociación correspondiente
	a 'clave'.
	El tiempo de ejecución es O(1) en promedio.
*/

bool existeAsociacionEnMap(nat clave, TMapping map){ return map->valorNat[clave] != 0; }
/*
  Devuelve el valor correspondiente a la asociacion de 'clave' en 'h'.
  Precondición: existeAsociacionenMap(clave, h).
  El tiempo de ejecución es O(1) en promedio.
 */
double valorEnMap(nat clave, TMapping map) {
//	assert(existeAsociacionEnMap(clave, map));
	return realInfo(map->dato[clave]);
}
/*
  Devuelve 'true' si y solo si 'map' tiene 'M' elementos, siendo 'M' el
  parámetro pasado en crearMap.
  El tiempo de ejecución es O(1).
 */
bool estaLlenoMap(TMapping map) { return map->tamanio == map->cantidadActual; }

/*
  Libera la memoria asignada a 'map' y todos sus elementos.
  El tiempo de ejecución en el peor caso es O(M), siendo 'M' el parámetro
  pasado en crearMap.
 */
void liberarMap(TMapping map) {
	delete[] map->dato;
	delete[] map->valorNat;
	delete map;
}